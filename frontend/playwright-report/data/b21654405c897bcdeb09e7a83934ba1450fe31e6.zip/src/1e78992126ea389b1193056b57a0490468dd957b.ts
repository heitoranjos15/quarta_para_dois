import { test } from '@playwright/test';

test('visual check - manual browser interaction', async ({ page }) => {
  test.setTimeout(120000);
  // This test keeps the browser open for manual inspection
  await page.goto('http://localhost:5174/game/2026_03_ATL_GB');
  await page.waitForTimeout(5000);
  
  console.log('=== Page loaded. Click the Play-by-Play tab manually ===');
  
  // Keep browser open for 60 seconds for manual inspection
  await page.waitForTimeout(60000);
});